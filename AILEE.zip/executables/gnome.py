'''
What am I?
'''

from termcolor import colored

def run(*args, **kwargs):
  print(colored('Ho ho ho ha ha, ho ho ho he ha. Hello there, old chum. I’m gnot a gnelf. I’m gnot a gnoblin. I’m a gnome. And you’ve been, GNOMED', 'yellow'))