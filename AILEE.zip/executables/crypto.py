"""
Why are you here?
"""

def run(*args, **kwargs):
  assert len(args) == 0, "no arguments needed"